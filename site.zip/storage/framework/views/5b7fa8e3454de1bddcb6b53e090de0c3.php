<button class="btn btn-primary btn-add" wire:click = 'add(<?php echo e($product->id); ?>)'>
    В корзину
</button>
<?php /**PATH /home/administrator/StartupItTest/project/startupit/resources/views/livewire/add-to-basket.blade.php ENDPATH**/ ?>