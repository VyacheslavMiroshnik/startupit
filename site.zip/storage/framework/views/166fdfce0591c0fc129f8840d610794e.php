<?php $__env->startSection('title','cart'); ?>
<?php $__env->startSection('style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/cart.css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main>


        <div class="container">
            <h1 class="text-center mt-5">Корзина</h1>
            <div class="row mb-4">
            <?php if(!count($products)): ?>
                    <div class="col-12 col-lg-8">
                    <h2>Корзина пуста</h2>
                    </div>
                <?php endif; ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-lg-8">
                    <article class="card mt-4 overflow-hidden">
                        <div class="row">
                            <div class="col-12 col-sm-4">
                                <div class="img-wrap">
                                    <img class="w-100" src="<?php echo e(asset('storage/img')); ?>/<?php echo e($product->img); ?>" alt="Изображение товара">
                                </div>
                            </div>
                            <div class="col-12 col-sm-8 d-flex align-items-center">
                                <div class="p-3">
                                    <h3 class="fs-6 mb-2">
                                       <?php echo e($product->description); ?>

                                    </h3>
                                    <p>
                                        <?php echo e($products->where('id',$product->id)->first()->pivot->count); ?>

                                    </p>
                                    <p class="fw-bold fs-6 m-0">
                                        цена без скидки - <?php echo e($product->price); ?> ₽ / шт.
                                    </p>
                                    <p class="fw-bold fs-6 m-0">
                                        с учётом скидки <span>5%</span> - 734 616 ₽ / шт.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-12 col-lg-4">
                    <div class="card p-3 mt-4">
                        <p class="fs-4">Общая сумма заказа:</p>
                        <p class="fw-bold">773 280 ₽</p>
                        <p class="fs-4">Общая сумма заказа c учётом скидки <span>5%</span>:</p>
                        <p class="fw-bold">734 616 ₽</p>
                        <button class="btn btn-primary">Заказать</button>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/administrator/StartupItTest/project/startupit/resources/views/cart.blade.php ENDPATH**/ ?>