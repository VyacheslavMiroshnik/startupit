<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('style'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/index.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <main>
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-6 col-lg-4 col-xl-3">
                    <article class="card mt-5 overflow-hidden border-primary  product__card" data-id="<?php echo e($product->id); ?>">
                        <div class="img-wrap">
                            <img class="w-100" src="<?php echo e(asset('storage/img')); ?>/<?php echo e($product->img); ?>" alt="Изображение товара">
                        </div>
                        <div class="p-3">
                            <h3 class="fs-6 mb-3">
                                <?php echo e($product->description); ?>

                            </h3>
                            <div class="d-flex align-items-center justify-content-between">
                                <p class="fw-bold fs-5 m-0">
                                    <?php echo e($product->price); ?>

                                </p>
                                <?php if(auth()->guard()->guest()): ?>
                                    <a class="btn btn-primary btn-add__cart"  href="<?php echo e(route('login')); ?>">
                                        В корзину
                                    </a>
                                <?php endif; ?>

                                <?php if(auth()->guard()->check()): ?>
                                    <?php if(!$carts->contains($product->id)): ?>
                                    <button class="btn btn-primary btn-add__cart" >
                                        В корзину
                                    </button>
                                    <?php else: ?>
                                            <div class="d-flex align-items-center gap-3  cart__counter">
                                                <button class="btn btn-outline-primary btn-diff__product">-</button>
                                                <span class="count"><?php echo e($carts->where('id',$product->id)->first()->pivot->count); ?></span>
                                                <button class="btn btn-outline-primary btn-add__product">+</button>
                                            </div>
                                     <?php endif; ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </article>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         <?php echo e($products->links()); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/administrator/StartupItTest/project/startupit/resources/views/index.blade.php ENDPATH**/ ?>